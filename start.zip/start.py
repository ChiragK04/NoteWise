import os

os.system("uvicorn app.main:app --port 8000 --reload")
